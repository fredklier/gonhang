class Version:
    @staticmethod
    def getVersion():
        return '0.2.3'
