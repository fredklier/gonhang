class Version:
    @staticmethod
    def getVersion():
        return '0.1.3'
